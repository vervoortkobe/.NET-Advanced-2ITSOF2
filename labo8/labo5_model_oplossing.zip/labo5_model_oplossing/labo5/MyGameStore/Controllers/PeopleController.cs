﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MyGameStore.DAL;
using MyGameStore.Model;
using System;
using System.Collections.Generic;
using System.Linq;

namespace WebApplication1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PeopleController : ControllerBase
    {
        private readonly MyGameStoreContext context;

        public PeopleController(MyGameStoreContext context)
        {
            this.context = context;
        }

        [HttpGet]   //api/people?lastnamefilter=Janssens&EmailFilter="@ap.be"
        public IActionResult GetAllPeople([FromQuery] string LastNameFilter = null, Gender? GenderFilter = null, string EmailFilter = null, Sort? sortBy = null)
        {
            //Starting to build query taking into account the parameters given
            //As long as we work with IQueryable the actual query is not performed yet (deferred execution)
            IQueryable<Person> query = context.People;         //using Method syntax
            //IQueryable<Person> query = from p in context.People select p;   //alternative: using Query syntax

            //filtering first, any parameter that is not null is used for filtering (where clauses can be chained)
            if (LastNameFilter != null)
                query = query.Where(p => p.LastName.Contains(LastNameFilter));
            //query = from p in query where p.LastName.Contains(LastNameFilter) select p;
            if (GenderFilter != null)
                query = query.Where(p => p.Gender == GenderFilter);
            //query = from p in query where p.Gender == GenderFilter select p;
            if (EmailFilter != null)
                query = query.Where(p => p.Email.Contains(EmailFilter));
            //query = from p in query where p.Email.Contains(EmailFilter) select p;

            switch (sortBy)
            {
                case Sort.ByBirthDate:
                    query = query.OrderBy(p => p.BirthDate);
                    //query = from p in query orderby p.BirthDate select p;
                    break;
                case Sort.ByLastName:
                    query = query.OrderBy(p => p.LastName);
                    //query = from p in query orderby p.LastName select p;
                    break;
                default:
                    break;
            }

            //Here (converting to list) is where the actual query is performed on the database !
            return Ok(query.ToList());
        }


        [HttpGet]
        [Route("{id}")]
        public IActionResult GetPerson(int id)
        {
            var person = context.People.Include(p => p.Employer).FirstOrDefault(p => p.Id == id);
            if (person != null)
                return Ok(person);

            return NotFound();
        }


        [HttpPost]
        public IActionResult CreatePerson([FromBody]Person person)
        {
            context.People.Add(person);
            context.SaveChanges();
            return Created("", person);
        }

        
        [Route("{id}")]  //api/people/id
        [HttpDelete]
        public IActionResult DeletePerson (int id, [FromHeader(Name ="X-AccessKey")]string AccessKey)
        {
            if(AccessKey != "123456789") return Unauthorized();
            
            var existing = context.People.Find(id);
            if (existing == null)
                return NotFound();

            context.People.Remove(existing);
            context.SaveChanges();
            
            return NoContent();
        }

        [HttpPut]
        [Route("{id}")]
        public IActionResult UpdatePerson(int id, [FromBody]Person updatedPerson)
        {
            Person person = null;
            if (id != updatedPerson.Id) 
                return BadRequest();
            
            context.People.FirstOrDefault(p => p.Id == id);
            if (person == null)
                return NotFound();

            person.FirstName = updatedPerson.FirstName;
            person.LastName = updatedPerson.LastName;
            person.BirthDate = updatedPerson.BirthDate;
            person.Gender = updatedPerson.Gender;
            context.SaveChanges();
            return Ok(person);
        }

        public enum Sort
        {
            ByLastName,
            ByBirthDate
        }
    }
}
