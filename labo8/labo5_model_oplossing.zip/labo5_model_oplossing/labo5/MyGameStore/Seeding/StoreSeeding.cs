﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using MyGameStore.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MyGameStore.Seeding
{
    public static class StoreSeeding
    {
        public static void Seed(this EntityTypeBuilder<Store> modelBuilder)
        {
            for (int i = 1; i <= 101; i++)
            {
                modelBuilder.HasData(
                new Store()
                {
                    Id = -i,
                    Name = "Store " + i,
                    Street = "StoreStreet",
                    Number =  i*3 +"A",
                    Zipcode = "2000",
                    City = "Antwerp",
                    IsFranchiseStore = new Random().Next(1) > 0,
                    Addition = ""
                }
            );
            }
        }
    }
}
