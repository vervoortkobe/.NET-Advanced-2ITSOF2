﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using Zolando.OrderSystem.API.DAL;
using Zolando.OrderSystem.API.Model;

namespace Zolando.OrderSystem.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderController : ControllerBase
    {
        private readonly OrderSystemContext context;

        public OrderController(OrderSystemContext context)
        {
            this.context = context;
        }

        [HttpGet]   
        public IActionResult GetAll()
        {
            return Ok(context.Orders);
        }


        [HttpGet]
        [Route("{id}")]
        public IActionResult Get(int id)
        {
            var store = context.Orders.FirstOrDefault(p => p.Id == id);
            if (store != null)
                return Ok(store);

            return NotFound();
        }


        [HttpPost]
        public IActionResult Create([FromBody] Order order)
        {
            context.Orders.Add(order);
            context.SaveChanges();
            return Created("", order);
        }


        [Route("{id}")]  
        [HttpDelete]
        public IActionResult Delete(int id)
        {
            var existing = context.Orders.Find(id);
            if (existing == null)
                return NotFound();

            context.Orders.Remove(existing);
            context.SaveChanges();
            return NoContent();
        }

        [HttpPut]
        [Route("{id}")]
        public IActionResult Update(int id, [FromBody] Order updatedItem)
        {
            if (id != updatedItem.Id)
                return BadRequest();

            var existing = context.Orders.Find(id);
            if (existing == null)
                return NotFound();

            existing.Date = updatedItem.Date;
            existing.Status = updatedItem.Status;

            context.SaveChanges();
            return Ok(updatedItem);
        }
    }
}
